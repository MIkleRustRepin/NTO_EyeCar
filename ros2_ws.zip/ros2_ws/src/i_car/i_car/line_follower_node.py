from std_msgs.msg import Float32
import rclpy
from rclpy.node import Node
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
import cv2
import numpy as np

class LineFollowerNode(Node):
    def __init__(self):
        super().__init__('line_follower_node')
        self.get_logger().warning("Line foillower started")
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        self.angle_pub = self.create_publisher(Float32, '/angle_stream', 10)
        self.speed_pub = self.create_publisher(Float32, '/speed_stream', 10)
        self.default_speed = 7.0
        self.k_p = 0.07
        self.k_d = 0
        self.prev_error = 0

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower_white = np.array([0, 0, 200])
        upper_white = np.array([180, 40, 255])
        mask = cv2.inRange(hsv, lower_white, upper_white)

        h, w = mask.shape[:2]
        roi = mask[int(h * 0.97):h, w // 2:w]
        roi = cv2.resize(roi, (64, 64))

        ys, xs = np.where(roi > 0)
        if len(xs) == 0:
            error = 0
        else:
            top_idx = np.argmin(ys)
            bottom_idx = np.argmax(ys)
            x_top = xs[top_idx]
            x_bottom = xs[bottom_idx]
            x_mean = (x_top + x_bottom) / 2.0
            error = x_mean - 32

        angle = self.k_p * error + self.k_d * (error - self.prev_error)
        self.prev_error = error

        angle_msg = Float32()
        angle_msg.data = float(angle * -27)
        self.angle_pub.publish(angle_msg)

        speed_msg = Float32()
        speed_msg.data = self.default_speed
        self.speed_pub.publish(speed_msg)

def main(args=None):
    rclpy.init(args=args)
    node = LineFollowerNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()

if __name__ == '__main__':
    main()
