import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from vision_msgs.msg import Detection2DArray, Detection2D, BoundingBox2D
from cv_bridge import CvBridge
import cv2
import torch
from ultralytics import YOLO


class YOLONode(Node):
    def __init__(self):
        super().__init__('yolo_node')
        self.get_logger().warning("YOLO node started")
        self.model = YOLO("/home/pi/ros2_ws/src/i_car/i_car/yolo26n_ncnn_model")
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        self.publisher = self.create_publisher(Detection2DArray, '/vision/objects', 10)

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        results = self.model(frame, imgsz=320)

        detections = Detection2DArray()
        detections.header = msg.header

        for result in results:
            for box in result.boxes:
                detection = Detection2D()
                detection.header = msg.header
                detection.bbox.center.x = float(box.xywh[0, 0])
                detection.bbox.center.y = float(box.xywh[0, 1])
                detection.bbox.size_x = float(box.xywh[0, 2])
                detection.bbox.size_y = float(box.xywh[0, 3])
                detections.detections.append(detection)

        self.publisher.publish(detections)

def main():
    rclpy.init()
    node = YOLONode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

