#!/bin/bash

# Активируем ROS2 и рабочее пространство
sudo pigpiod
source /opt/ros/jazzy/setup.bash
source ~/ros2_ws/install/setup.bash

# Запуск нод на разных ядрах (для 4‑ядерного CPU: 0, 1, 2, 3)
taskset -c 0 ros2 run i_car camera_node &
taskset -c 1 ros2 run i_car yolo_node &
taskset -c 2 ros2 run i_car line_follower_node &
taskset -c 3 ros2 run i_car drive_node &

# Ждём завершения (Ctrl+C остановит все)
wait
